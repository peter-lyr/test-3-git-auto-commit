<!-- Copyright (c) 2024 liudepei. All Rights Reserved. -->
<!-- create at 2024/03/06 19:24:15 Wednesday -->

<!-- toc -->

- [hi](#hi)

<!-- tocstop -->

# hi

`ssh -T git@github.com`

1. `ssh-keygen -t ed25519 -C "llydrp.ldp@gmail.com"`
2. copy id_ed25519.pub to `https://github.com/settings/keys`
